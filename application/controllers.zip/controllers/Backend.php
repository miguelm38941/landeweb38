<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Backend extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

	private $global_access = array('pnls','lmsc');

	function __construct(){
		parent::__construct();
		$this->load->helper('lgedit');
		$this->load->library('email');
		$this->load->library('Pdf');
		$this->load->helper('lgpdf');

		if(!$this->ion_auth->logged_in()){
			redirect('auth/login');			
		}
		/*
		$this->client_id = false;
		if($this->ion_auth->in_group('clients')){
			$id = $this->session->userdata('user_id');	
			$this->client_id = $this->mlns->get_client_from_userid($id);
			//echo $this->client_id;die();
			if(!is_numeric($this->client_id)) die('CLIENT NOT ASSIGNED');

			//redirect('clients');			
		}
		*/
		$this->syncUsers();
	}

	public function index(){
		$this->load->view('welcome');
		///redirect('backend/welcome');
	}
	
	/*function telecharger(){
		$this->load->helper('download');
		force_download(APPPATH . 'telecharger/landela_app.apk', NULL);
		//$this->load->view('welcome');
		//$data = file_get_contents(APPPATH . 'controllers/upload/project_name/bc68gdas9jfeh9yfj/'.$this->uri->segment(3)); // Read the file's contents
		//$name = $this->uri->segment(3);
		//force_download($name, $data);
	}*/

	function telecharger(){
        $yourFile = APPPATH . 'telecharger/landela_app.apk';
        $file = @fopen($yourFile, "rb");

        header('Content-Description: File Transfer');
        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename=landela_app.apk');
        header('Expires: 0');
        header('Cache-Control: must-revalidate');
        header('Pragma: public');
        header('Content-Length: ' . filesize($yourFile));
        while (!feof($file)) {
            print(@fread($file, 1024 * 8));
            ob_flush();
            flush();
        }
	}

	public function propositions(){
		$uid = $this->session->userdata('user_id');	
		$filters=array();
		if($this->ion_auth->in_group(array('medecin'))){
			$filters['user']=$uid;
		}
		$datas=array();
		$datas['table']="propositions";
		$datas['title']="propositions";
		$datas['datas']=$this->lg->get_datas('propositions',$filters,true);
		$datas['can_add']=true;
		$datas['options']=array(
				'can_edit' => false,
				'can_delete' => false,
				'hide_columns' => array('id')
				//'dbclick' => '/taaps/projects'
				);
		$datas['hooks_add']=true;
		$this->load->view('lgedit/show',$datas);
	}	

	public function produits(){
		$datas=array();
		$datas['table']="produits";
		$datas['title']="Produits";
		$datas['datas']=$this->lg->get_datas('produits');
		$datas['can_add']=true;
		$datas['options']=array(
				'can_edit' => true,
				'can_delete' => false,
				'hide_columns' => array('id'),
				'links' => array(
					'assignment' => '/backend/produits/show'
					)
				//'dbclick' => '/taaps/projects'
				);
		$datas['hooks_add']=true;
		$this->load->view('lgedit/show',$datas);
	}
	
	public function regionsante(){
		$datas=array();
		$datas['table']="regionsante";
		$datas['title']="Centre de Distribution R&eacute;gional";
		$datas['datas']=$this->lg->get_datas('regionsante');
		$datas['can_add']=true;
		$datas['options']=array(
				'can_edit' => true,
				'can_delete' => false,
				'hide_columns' => array('id')
				//'dbclick' => '/taaps/projects'
				);
		$this->load->view('lgedit/show',$datas);
	}	
	
	public function zonesante(){
		$datas=array();
		$datas['table']="zonesante";
		$datas['title']="Aire sante";
		$datas['datas']=$this->lg->get_datas('zonesante');
		$datas['can_add']=true;
		$datas['options']=array(
				'can_edit' => true,
				'can_delete' => false,
				'hide_columns' => array('id')
				//'dbclick' => '/taaps/projects'
				);
		$this->load->view('lgedit/show',$datas);
	}	

	public function educateur(){
		$datas=array();
		$datas['table']="educateur";
		$datas['title']="Educateur";
		$datas['datas']=$this->lg->get_datas('educateur');
		$datas['can_add']=true;
		$datas['options']=array(
				'can_edit' => true,
				'can_delete' => false,
				'hide_columns' => array('id')
				//'dbclick' => '/taaps/projects'
				);
		$this->load->view('lgedit/show',$datas);
	}	

	public function societe_pharma(){
		$datas=array();
		$datas['table']="societe_pharma";
		$datas['title']="Societe Pharmacetique";
		$datas['datas']=$this->lg->get_datas('societe_pharma');
		$datas['can_add']=true;
		$datas['options']=array(
				'can_edit' => true,
				'can_delete' => false,
				'hide_columns' => array('id')
				//'dbclick' => '/taaps/projects'
				);
		$datas['hooks_add']=true;
		$this->load->view('lgedit/show',$datas);
	}	
	
	public function pharmacie(){
		$datas=array();
		$datas['table']="pharmacie";
		$datas['title']="Preposes pharmacie";
		$datas['datas']=$this->lg->get_datas('pharmacie');
		$datas['can_add']=true;
		$datas['options']=array(
				'can_edit' => true,
				'can_delete' => false,
				'hide_columns' => array('id')
				//'dbclick' => '/taaps/projects'
				);
		$datas['hooks_add']=true;
		$this->load->view('lgedit/show',$datas);
	}	
	
	public function partenaire(){
		$datas=array();
		$datas['table']="partenaire";
		$datas['title']="Partenaire";
		$datas['datas']=$this->lg->get_datas('partenaire');
		$datas['can_add']=true;
		$datas['options']=array(
				'can_edit' => true,
				'can_delete' => false,
				'hide_columns' => array('id')
				//'dbclick' => '/taaps/projects'
				);
		$datas['hooks_add']=true;
		$this->load->view('lgedit/show',$datas);
	}	
	
	public function medecin(){
		$datas=array();
		$datas['table']="medecin";
		$datas['title']="Medecins";
		$datas['datas']=$this->lg->get_datas('medecin');
		$datas['can_add']=true;
		$datas['options']=array(
				'can_edit' => true,
				'can_delete' => false,
				'hide_columns' => array('id')
				//'dbclick' => '/taaps/projects'
				);
		$datas['hooks_add']=true;
		$this->load->view('lgedit/show',$datas);
	}	

	public function agent(){
		$datas=array();
		$datas['table']="agent";
		$datas['title']="formation sanitaire";
		$datas['datas']=$this->lg->get_datas('agent');
		$datas['can_add']=true;
		$datas['options']=array(
				'can_edit' => false,
				'can_delete' => false,
				'hide_columns' => array('id')
				//'dbclick' => '/taaps/projects'
				);
		if(!$this->ion_auth->in_group(array('partenaire'))){
			$datas['options']['can_edit']=true;
		}
		$datas['hooks_add']=true;
		$this->load->view('lgedit/show',$datas);
	}	

	public function mail_alertes($receiver, $send=false){

		if ($send) {
$this->email->from('arsoonic@gmail.com', 'Landela');
$this->email->to('m.miguellao@gmail.com');
//$this->email->cc('another@another-example.com');
//$this->email->bcc('them@their-example.com');
$this->email->subject('Email Test');
$this->email->message('Testing the email class from landela.');
$this->email->send();
		}
		$datas=array();
		$datas['table']="alertes_mail";
		$datas['title']="Alertes e-mail";
		$datas['datas']=$this->lg->get_datas('agent');
		$datas['can_add']=true;
		$datas['options']=array(
				'can_edit' => false,
				'can_delete' => false,
				'hide_columns' => array('id')
				//'dbclick' => '/taaps/projects'
				);
		if(!$this->ion_auth->in_group(array('partenaire'))){
			$datas['options']['can_edit']=true;
		}
		$datas['hooks_add']=true;
		$this->load->view('alertes_email',$datas);
	}	

	public function alertes($param=false){
		$filters=array();
		$uid = $this->session->userdata('user_id');	
		$filters['user']=$uid;

		$ss=get_warning(false);
		//print_r($ss);	
		if ($this->ion_auth->in_group($this->global_access)) {
			if(isset($param)){
				$datas['table']="pharmacie";
				$datas['can_add']=true;
				$datas['options']=array(
						'can_edit' => true,
						'can_delete' => false,
						'hide_columns' => array('id')
						//'dbclick' => '/taaps/projects'
					);
				$datas['hooks_add']=true;
				if($param=='peremption'){
					$perimes=$this->computeProduitsPerimes($ss['perimer']);
					$datas['title']="Preposes pharmacie";
					$datas['datas']=$perimes;
					$this->load->view('alertes_generic',$datas);
					return;
				}elseif($param=='outofstock'){//var_dump($ss['produits']); exit;
					$epuises=$this->computeProduitsStockEpuise($ss['produits']);
					$datas['title']="Preposes pharmacie";
					$datas['datas']=$epuises;
					$this->load->view('alertes_epuise',$datas);
					return;
				}	
			}	
		}/**/
				
		$res=array();
		foreach($ss['produits'] as $r){
			$res[]=array(
					'id' => '1',
					'produit' => $r,
					'quantite' => 0,
					'peremption' => ''
					);	
		}
		//print_r($res);

		$datas=array();
		$datas['table']="stock";
		$datas['title']="Stock";
		$datas['datas']=$res;
		$datas['can_add']=false;
		$datas['options']=array(
				'can_edit' => false,
				'can_copy' => false,
				'can_delete' => false,
				'hide_columns' => array('id','quantite','peremption')
				);
//var_dump($res);exit;
		$datas2=array();
		$datas2['table']="stock";
		$datas2['title']="Stock";
		$datas2['datas']=$ss['peremption'];
		$datas2['can_add']=false;
		$datas2['options']=array(
				'can_edit' => false,
				'can_copy' => false,
				'can_delete' => false,
				'hide_columns' => array('id')
				);

		$datas3=array();
		$datas3['table']="stock";
		$datas3['title']="Stock";
		$datas3['datas']=$ss['perimer'];
		$datas3['can_add']=false;
		$datas3['options']=array(
				'can_edit' => false,
				'can_copy' => false,
				'can_delete' => false,
				'hide_columns' => array('id')
				);
		$this->load->view('alertes',array('datas' => $datas,'datas2' => $datas2,'datas3' => $datas3,'hide_alert' => true));
	}

	public function stock($action=false,$id=false){
		$filters=array();
		$uid = $this->session->userdata('user_id');	
		$cid = $this->session->userdata('organisation');
		if(!$this->ion_auth->in_group(array('pnls','lmsc'))){
			$filters['user']=$cid;
		}	
		
		$ss=$this->lg->get_datas('stock',$filters,true);

		$res=array();
		foreach($ss as $s){
			if($this->ion_auth->in_group(array('pnls','lmsc'))){
				$company = $this->lg->get_company($s['user']);
				@$s['company'] = $company->nom;
			}	
			//var_dump($s); echo "<br>";
			if (isset($s['peremption'])){
				if(strtotime($s['peremption']) > strtotime(date('Y-m-d H:i:s'))){
					if($s['quantite'] > 0){
						$res[]=$s;
					}
				}
			}	
		}

		if($action == "show"){
			$res=$this->lg->get_data('produits',array('id' => $id),true);
			//$res2=$this->lg->get_data('pvv',array('id' => $res['pvv']),true);
			$this->load->view('ordonnance',array('ordonnance' => $res, 'pvv' => $res2));
			return;
		}

		$datas=array();
		$datas['table']="stock";
		$datas['title']="Stock";
		$datas['datas']=$res;
		$datas['can_add']=true;
		$datas['options']=array(
				'can_edit' => false,
				'can_delete' => false,
				'hide_columns' => array('id'),
				'links' => array(
					'assignment' => '/backend/produits/show'
					)
				//'dbclick' => '/taaps/projects'
				);
		if(!$this->ion_auth->in_group(array('pnls','lmsc'))){
			$datas['options']['hide_columns'][]='company';
		}else{
			$datas['options']['links']['send']='/backend/produits/mail';
		}
		$datas['hooks_add']=true;
		$this->load->view('lgedit/show',$datas);
	}	

	public function consultations($action=false,$id=false){
		$datas=array();
		$res=$this->lg->get_datas('consultation',array('etat' => 'En attente'),true);
		if($this->ion_auth->in_group(array('agent'))){
			$user_group = 'agent';
		}elseif($this->ion_auth->in_group(array('medecin'))){
			$user_group = 'medecin';
		}
		$selectedconsultList = array();
		foreach ($res as $consult) {//$this->session->userdata('user_id')
			if(isset($consult[$user_group]) && 
				$consult[$user_group]==$this->session->userdata('user_id') && 
				($consult['etat']=='En attente')
				){			
				array_push($selectedconsultList, $this->lg->get_data('pvv',array('id' => $consult["pvv"])));
			}
		}
		
		$datas['table']="pvv";
		$datas['title']="Consultations en atttente";
		$datas['datas']=$selectedconsultList;
		$datas['can_add']=true;
		$datas['options']=array(
				'consultation' => true,
				'can_edit' => false,
				'can_delete' => false,
				'links' => array(
					'person' => '/backend/profile_pvv'
					),
				'columns' => array(
					'code' => array(
						'label' => 'Code',
						'type' => 'text'
						)
					),
				
				//'dbclick' => '/taaps/projects'
				);
		if($this->ion_auth->in_group(array('agent'))){
			$datas['options']['hide_columns']=array('id','cnib','regionsante','zonesante','nom','prenom','telephone','adresse');
		}elseif($this->ion_auth->in_group(array('medecin'))){
			$datas['options']['hide_columns']=array('id','cnib','regionsante','zonesante');
		}
						
		$this->load->view('pvv/consultations',$datas);

	}	
	
	public function ordonnances($action=false,$id=false){

		$datas=array();
		$filters=array();
		$uid = $this->session->userdata('user_id');	
		$cid = $this->session->userdata('company');	

		if($action == "show"){
			$res=$this->lg->get_data('ordonnances',array('id' => $id),true);
			$res2=$this->lg->get_data('pvv',array('id' => $res['pvv']),true);
			$this->load->view('ordonnance',array('ordonnance' => $res, 'pvv' => $res2));
			return;
		}

		if($action == "search"){
			$res=$this->lg->get_data('ordonnances',array('prepose_pharmacie' => $uid),true);
			$res2=$this->lg->get_data('pvv',array('id' => $res['pvv']),true);
			$this->load->view('ordonnance',array('ordonnance' => $res, 'pvv' => $res2));
			return;
		}
//var_dump($datas);

		if($action == "deliver"){
			if($this->lg->get_data('ordonnances',array('id' => $id,'delivered' => ''))){

				$datas = $this->lg->get_data('ordonnances',array('id' => $id),true);
				$datas['produits'] = json_decode($datas['produits'],true);
				$r=stock_decrease($cid,$datas['produits'],true);

				if($r){
					stock_decrease($cid,$datas['produits']);
					$this->lg->set_data('ordonnances',$id,array('prepose_pharmacie' => $uid,'delivered' => date('Y-m-d H:i:s')),false);
				}else{
					echo "<h1>Stock non disponible</h1>";
					return;
				}
			}
			redirect('/backend/pvv/ordonnances');

		}

		if($action == "pvv"){
			if(!$id){
				$code = $this->input->post('search');
				redirect('/backend/ordonnances/pvv/'.$code);
			}else{
				$filters['pvv']=$id;
			}
		}

		if($this->ion_auth->in_group(array('medecin'))){
			$filters['user']=$uid;
		}
		//var_dump($ordonnances); exit;
		/*if(isset($filters['user']))
			foreach($ordonnances as $key=>$value){
				$user = $this->lg->get_user($filters['user']);
				$medecin['id'] = $filters['user'];
				$medecin['username'] = $user['username'];
				$ordonnances[$key]['medecin'] = $medecin;
			}*/
		$datas['table']="ordonnances";
		$datas['title']="Ordonnances";
		$datas['can_add']=true;
		$datas['options']=array(
				'can_edit' => false,
				'can_copy' => false,
				'can_delete' => false,
				'columns' => array(
					'created' => array(
						'label'  => 'Cr&eacute;e le',
						'type' => 'text'
						),
					'delivered' => array(
						'label' => 'Livr&eacute;e le',
						'type' => 'text'
						)
					),
				'buttons' => array(
					//'livrer' => '/backend/ordonnances/deliver'
					),
				'links' => array(
					'assignment' => '/backend/ordonnances/show'
					)
					//'dbclick' => '/taaps/projects'
					);
		//var_dump($datas['datas']);

		$datas['options']['hide_columns'] = array('id','produits','commentaires');

		if($this->ion_auth->in_group(array('pharmacie'))){
			$filters['prepose_pharmacie']=$this->session->userdata('user_id');
			$datas['options']['hide_columns'] = array('id','produits','commentaires','prepose_pharmacie');
			$datas['options']['buttons']=array(
							'livrer' => '/backend/ordonnances/deliver'
						);
			//$datas['options']['buttons']=array();
			//$filters['delivered']='!isset';
		}

		if(!$this->ion_auth->in_group(array('medecin'))){
			$datas['can_add']=false;
		}

		$ordonnances = $this->lg->get_datas('ordonnances',$filters,true);
		foreach ($ordonnances as $k=>$ordonnance) {
			if(isset($ordonnance['prepose_pharmacie'])){
				$ordonnances[$k]['prepose_pharmacie']=$this->lg->get_user_company($ordonnance['prepose_pharmacie']);
			}
			
		}
		//echo '<pre>';
		//var_dump($datas); echo '</pre>'; echo '--------'; exit;
		$datas['datas']=$ordonnances;
		$this->load->view('lgedit/show',$datas);
	}	

	public function commandes($action=false,$id=false){

		$datas=array();
		$filters=array();
		$uid = $this->session->userdata('user_id');	
		$cid = $this->session->userdata('organisation');	
		if($action == "add_societe_pharma"){
			$id = $this->input->post('id');
			$sc = $this->input->post('societe_pharma');
			$this->lg->set_data('commandes',$id,array('societe_pharma' => $sc,'sent_societe_pharma' => date('Y-m-d H:i:s')),false);
			return;
		}
		if($action == "show"){
			$res=$this->lg->get_data('commandes',array('id' => $id));
			$this->load->view('commande',array('commande' => $res));
			return;
		}
		if($action == "send"){
			if($this->lg->get_data('commandes',array('id' => $id,'sent' => '!isset'))){
				$this->lg->set_data('commandes',$id,array('sent' => date('Y-m-d H:i:s')),false);
			}
			redirect('/backend/commandes');
		}
		if($action == "deliver"){
			/*if(isset($_POST)){
				$id = $_POST['id'];
				$peremption = array_unique($_POST['peremption']);
				$quantites = $_POST['quantites'];
				$produits = $_POST['produits'];
			}
			foreach ($produits as $key => $value) {
				$prdts[$key]['produit'] = $value;
			}
			foreach ($quantites as $key => $value) {
				$prdts[$key]['quantite'] = $value;
			}
			foreach ($peremption as $key => $value) {
				$prdts[$key]['peremption'] = $value;
			}*/
			if($this->lg->get_data('commandes',array('id' => $id,'delivered' => '!isset'))){
				$datas = $this->lg->get_data('commandes',array('id' => $id));
				$datas['produits'] = json_decode($datas['produits'],true);
				//var_dump($datas['produits']); exit;
				$r=stock_decrease($cid,$datas['produits'],true);
				if($this->ion_auth->in_group(array('societe_pharma'))){
					$r=true;
				}
				if($r){
					stock_decrease($cid,$datas['produits']);
					$this->lg->set_data('commandes',$id,array('delivered' => date('Y-m-d H:i:s')),false);
				}else{
					echo "<h1>Stock non disponible</h1>";
					return;
				}
			}
			redirect('/backend/commandes/filter/waiting_for_me');
		}
		if($action == "receipt"){
			if($this->lg->get_data('commandes',array('id' => $id,'received' => '!isset'))){
				$this->lg->set_data('commandes',$id,array('received' => date('Y-m-d H:i:s')),false);
				//redirect('/backend/commandes/filter/waiting');
				$datas = $this->lg->get_data('commandes',array('id' => $id));
				$datas['produits'] = json_decode($datas['produits'],true);
				foreach($datas['produits'] as $p){
					$datas = $this->lg->set_data('stock',false,$p);
				}
				//die();
			}
			redirect('/backend/commandes/filter/waiting_by_me');
		}

		if($action == "filter"){
			if($id == "waiting_by_me"){ 
				$title="Commandes en attente";
				$filters['sent']="isset";
				$filters['received']="!isset";
				$filters['user']=$cid;
				if($this->ion_auth->in_group(array('pnls','lmsc'))){
					unset($filters['user']);
				}
			}
			if($id == "waiting_for_me"){
				$title="Commandes &agrave; g&eacute;rer";
				$filters['sent']="isset";
				$filters['delivered']="!isset";
				$filters['destinataire']=$cid;
				if($this->ion_auth->in_group(array('pnls','lmsc'))){
					unset($filters['destinataire']);
				}
			}
			if($id == "received"){
				$title="Commandes re&ccedil;ues";
				$filters['received']="isset";
				$filters['user']=$cid;
				if($this->ion_auth->in_group(array('pnls','lmsc'))){
					unset($filters['user']);
				}
			}
			if($id == "delivered"){
				$title="Commandes Livr&eacute;es";
				$filters['delivered']="isset";
				$filters['destinataire']=$cid;
				if($this->ion_auth->in_group($this->global_access)){
					unset($filters['destinataire']);
				}
			}
		}else{
			$title="Commandes en cours";
			$filters['sent']="!isset";
			$filters['user']=$cid;
		}

		$datas['table']="commandes";
		$datas['title']=$title;
		$datas['datas']=$this->lg->get_datas('commandes',$filters,true);
		//if($this->ion_auth->in_group(array('pharmacie'))){
		$table1='pharmacie';
		//}elseif($this->ion_auth->in_group(array('regionsante'))){
		//	$table1='regionsante';
		//}
		if(isset($table1)){
//var_dump($datas['datas']);exit;		
			foreach ($datas['datas'] as $key => $value) {
				if (isset($datas['datas'][$key]['acheteur'])){ 
					$pharmacie=$this->lg->get_data($table1,array('id'=>$value['acheteur']),true);	
					$datas['datas'][$key]['acheteur']=$pharmacie['nom'];
				}
			}
		}
/*echo '<pre>';
	var_dump($datas['datas']['1']);
echo '</pre>';
exit;*/		
		$datas['can_add']=true;
		$datas['options']=array(
				'can_edit' => true,
				'can_copy' => false,
				'can_delete' => false,
				'hide_columns' => array('id','produits'),
				'columns' => array(
					'created' => array(
						'label' => 'Cree',
						'type' => 'text'
						)
					),
				'buttons' => array(
					'Commander' => '/backend/commandes/send'
					),
				'links' => array(
					'assignment' => '/backend/commandes/show'
					)
				//'dbclick' => '/taaps/projects'
				);

		if($action == "filter"){
			$datas['options']['can_edit']=false;
			$datas['options']['hide_columns'][]="created";
			if($id == "waiting_for_me"){
				$datas['options']['buttons']=array(
						'envoyer' => '/backend/commandes/deliver'
						);
				$datas['options']['hide_columns'][]="destinataire";
				$datas['options']['hide_columns'][]="user";
				$datas['options']['columns']['sent']=array(
						'label' => 'Effectu&eacute;e le',
						'type' => 'text'
						);
				$datas['options']['columns']['user']=array(
						'label' => 'Demandeur',
						'type' => 'select',
						'values' => 'get_all_destinataires_commandes'
						);
			}
			if($id == "waiting_by_me"){
				//if($this->ion_auth->in_group(array('pharmacie'))){
					$datas['options']['hide_columns'][]="acheteur";
				//}
				$datas['options']['buttons']=array(
						'receptionner' => '/backend/commandes/receipt'
						);
				$datas['options']['columns']['sent']=array(
						'label' => 'Envoyee',
						'type' => 'text'
						);
				$datas['options']['columns']['sent']['label']="Date";
			}
			if($id == "delivered"){
				$datas['options']['hide_columns'][]="destinataire";
				$datas['options']['buttons']=array();
				$datas['options']['columns']['sent']=array(
						'label' => 'Effectu&eacute;e le',
						'type' => 'text'
						);
				$datas['options']['columns']['delivered']=array(
						'label' => 'Livr&eacute;e le',
						'type' => 'text'
						);
			}
			if($id == "received"){
				if($this->ion_auth->in_group(array('pharmacie'))){
					$datas['options']['hide_columns'][]="acheteur";
				}
				$datas['options']['buttons']=array();
				$datas['options']['columns']['sent']=array(
						'label' => 'Effectu&eacute;e le',
						'type' => 'text'
						);
				$datas['options']['columns']['received']=array(
						'label' => 'Re&ccedil;ue le',
						'type' => 'text'
						);
			}
		}
		
		if($this->ion_auth->in_group($this->global_access)){
			$datas['options']['can_edit']=false;
			$datas['can_add']=false;
		}

		//var_dump($datas['datas']);exit;
		$this->load->view('lgedit/show',$datas);
	}	

	public function profile_pvv($id=false, $param1=false){

		$id2=$this->input->post('search');
		if($id == false && $id2 == false){
			$this->load->view("pvv/search");
			return;
		}

		if($id2){
			//$id = $ids2;
			$res=$this->lg->get_data('pvv',array('code' => $id2),true);
			$id=$res['id'];
			redirect('/backend/profile_pvv/'.$id.'/'.strtolower($id2));
		}else{ 
			$res=$this->lg->get_data('pvv',array('id' => $id));
		}

		$obs=$this->lg->get_datas('observations',array('pvv' => $id),true);

		$consult=$this->lg->get_data('consultation',array('pvv' => $id, 'etat' => 'En attente'));
		//if($this->session->userdata('user_id')=$consult['medecin']){
		

		$filters=array('pvv' => $res['id']);

		$datas=array();
		$datas['table']="ordonnances";
		$datas['datas']=$this->lg->get_datas('ordonnances',$filters,true);
		$datas['can_add']=true;
		$datas['options']=array(
				'can_edit' => false,
				'can_copy' => false,
				'can_delete' => false,
				'hide_columns' => array('pvv','produits','commentaires','consultation','etat'),
				'columns' => array(
					'id' => array(
						'label'  => 'Ordonnance N&deg;',
						'type' => 'text'
					),
					'created' => array(
						'label'  => 'Cr&eacute;e le',
						'type' => 'text'
					),
					'delivered' => array(
						'label' => 'Livr&eacute;e le',
						'type' => 'text'
						)
					),
				'buttons' => array(
					),
				'links' => array(
					'assignment' => '/backend/ordonnances/show'
					)
				//'dbclick' => '/taaps/projects'
					);

					if($id == false && $id2 == false){
						$this->load->view("pvv/search");
						return;
					}

		if($param1 && $param1=="qrprint"){
			generatePdf($res);
			return;
		}
		elseif($param1=="consultation"){
			if($this->ion_auth->in_group(array('medecin'))){
				$usergroup = 'medecin';
			}
			elseif($this->ion_auth->in_group(array('agent'))){
				$usergroup = 'agent';
			}
			$this->load->view('pvv/profil',array('infos' => $res, 'consultation' => $consult, 'usergroup' => $usergroup));
			return;
		}
		$this->load->view('pvv/profil',array('infos' => $res, 'ordonnances' => $datas, 'observations' => $obs));

	}

	public function pvv($action=false,$id=false){
		$datas=array();
		$filters=array();
		if($action == "educateur"){
			$id = $this->input->post('id');
			$edu = $this->input->post('educateur');
			$this->lg->set_data('pvv',$id,array('educateur' => $edu));
			return;
		}
		if($action == "note"){
			$id = $this->input->post('id');
			$obs = $this->input->post('observation');
			$this->lg->set_data('observations',false,array('pvv' => $id,'observation' => $obs));
			redirect('/backend/profile_pvv/'.$id);
		}
		if($action == "validate"){
			if($this->lg->get_data('pvv',array('id' => $id,'validate' => '!isset'))){
				$edu='';
				if($this->ion_auth->in_group(array('educateur'))){
					$edu = $this->session->userdata('user_id');	
				}
				$this->lg->set_data('pvv',$id,array('validate' => date('Y-m-d H:i:s'),'educateur'=>$edu),false);
			}
			redirect('/backend/pvv/filter/tovalidate');
			//return;
		}
		if($action == "filter"){
			if($id == "tovalidate"){
				$filters['educateur']="tocheck";
			}
		}else{
			if($this->ion_auth->in_group(array('educateur'))){
				$uid = $this->session->userdata('user_id');	
				$filters['educateur']=$uid;
			}
			if($this->ion_auth->in_group(array('medecin'))){
				/*$uid = $this->session->userdata('user_id');	
				$res=$this->lg->get_datas('ordonnances',array('user' => $uid),true);
				$ids=array();
				foreach($res as $r){
					if(isset($r['pvv'])) $ids[] = $r['pvv'];
				}
				$filters['code']=$ids;*/
				//array_unique(array)
			}
		}

		$datas['table']="pvv";
		$datas['title']="pvv";
		$datas['datas']=$this->lg->get_datas('pvv',$filters,true);
		$datas['can_add']=true;
		$datas['options']=array(
				'can_edit' => true,
				'can_delete' => false,
				'hide_columns' => array('id','nom','prenom','cnib'),
				'links' => array(
					'person' => '/backend/profile_pvv'
					),
				'columns' => array(
					'code' => array(
						'label' => 'Code',
						'type' => 'text'
						)
					)
				//'dbclick' => '/taaps/projects'
				);
		/*if($action == "ordonnances"){
			$datas['table']="ordonnances";
			$datas['title']="Ordonnances";
			$datas['options']['btn_ordonnances']=true;
			$datas['datas']=$this->lg->get_datas('ordonnances',$filters,true);
			//var_dump($datas['datas']); exit;
			//redirect('/backend/pvv');
			$this->load->view('pvv/ordonnances', $datas);
			//return;
		}*/
		if($action == "filter"){
			if($id == "tovalidate"){
				$datas['options']['can_edit']=false;
				$datas['options']['buttons']=array(
						'valider' => '/backend/pvv/validate'
						);
			}
		}
		if($this->ion_auth->in_group(array('medecin'))){
			//$datas['options']['btn_ordonnances']=true;
			$datas['options']['can_edit']=false;
		}

		$this->load->view('lgedit/show',$datas);
	}

	public function test(){
		//echo 2;
		//$res=get_group_users('educateur');
		//print_r($res);
		//$datas=array();
		$res = get_destinataires_commandes(true);
		//$res=hook_before_add_pvv($datas);
		var_dump($res);
		/*	
			$id=32;
			$uid=11;
			$datas = $this->lg->get_data('ordonnances',array('id' => $id),true);
			$datas['produits'] = json_decode($datas['produits'],true);
			stock_decrease($uid,$datas['produits']);
		 */
	}	

	function syncUsers(){
		$users = array(
				'societe_pharma' => 16,
				'agent' => 10,
				'medecin' => 9,
				'partenaire' => 6,
				'pharmacie' => 8,
				'educateur' => 11,
				'regionsante' => 14,
				'zonesante' => 15,
				);

		$filters = array(
				'auth_user' => '!isset'
				);

		foreach($users as $table => $group){
			$datas=$this->lg->get_datas($table,$filters,true);
			foreach($datas as $data){
				$identity=$data['username'];
				$email=isset($data['email']) ? $data['email'] : "";
				$additional_data=array();
				$groups = array($group); 
				if($id=$this->ion_auth->register($identity, '12345678', $email, $additional_data,$groups)){
					$this->lg->set_data($table,$data['id'],array('auth_user' => $id));
				}
			}
		}
	}

	function computeProduitsPerimes($prdts_perimer){
		$perim_array = array();
		foreach ($prdts_perimer as $perim) {
			array_push($perim_array, $perim['user']);
		} 
		$perim_array = array_unique($perim_array);
		$perimPharmacies = array();
		foreach ($perim_array as $pharmaId) {
			$res=$this->lg->get_data('pharmacie',array('id' => $pharmaId),true);
			//if(!empty($res)) array_push($perimPharmacies, $res);
			//var_dump($ss['perimer']);exit;
			foreach ($prdts_perimer as $perim) {//
				if ($perim['user']==$pharmaId){
					//echo $perim['user'].'=='.$pharmaId.'<br>';
					$perimes['pharmacie'] =  $res['nom'];
					$perimes['produit'] = $this->lg->get_data('produits',array('id' => $perim['produit']),true);
					$perimes['quantite'] =  $perim['quantite'];
					$perimes['peremption'] =  isset($perim['peremption'])? $perim['peremption']:'';
					array_push($perimPharmacies, $perimes);
				}
			} 
		}//var_dump($perimPharmacies);exit;
		return $perimPharmacies;
	}

	function computeProduitsStockEpuise($prdts_epuises){
		$perimPharmacies = array();
		foreach ($prdts_epuises as $k =>$epuise) {
			$prdts_epuises[$k]['pharmacie'] = $this->lg->get_data('pharmacie',array('id' => $epuise['pharmacie']),true);
			$prdts_epuises[$k]['produit'] = $this->lg->get_data('produits',array('id' => $epuise['produit']),true);
		}//var_dump($prdts_epuises); exit;
		return $prdts_epuises;
	}

}

