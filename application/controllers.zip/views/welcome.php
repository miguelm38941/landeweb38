<html>
<head>
<?php
	include_once(APPPATH.'/views/head.php');
?>
</head>
<body>
<div class="wrapper">
<?php
	include_once(APPPATH.'/views/menu.php');
?>
<main>
<div class="container">
<div class="valign-wrapper" style="height:550px;width:100%">
<br><br>
<h1 style="width:100%"class="center-align">Bienvenue sur Landela</h1>
</div>
</div>
</main>
</div>
<?php include_once(APPPATH.'/views/footer.php'); ?>
</body>
</html>
