<html>
<head>
<?php
	include_once(APPPATH.'/views/head.php');
?>
</head>
<body>
<?php
	include_once(APPPATH.'/views/menu.php');
?>
<main>
<div class="container">
<h3 style="background:#eee;padding:10px;">A commander</h3>
<div class="row">
<?php
	//echo lgedit_generate_table($datas['table'],array(),$datas['options']);
	echo lgedit_generate_table($datas['table'],$datas['datas'],$datas['options']);
?>
</div>
<h3 style="background:#eee;padding:10px;">En p&eacute;remption</h3>
<div class="row">
<?php
	//echo lgedit_generate_table($datas['table'],array(),$datas['options']);
	echo lgedit_generate_table($datas2['table'],$datas2['datas'],$datas2['options']);
?>
</div>
<h3 style="background:#eee;padding:10px;">P&eacute;rim&eacute;s</h3>
<div class="row">
<?php
	//echo lgedit_generate_table($datas['table'],array(),$datas['options']);
	echo lgedit_generate_table($datas3['table'],$datas3['datas'],$datas3['options']);
?>
</div>
</div>
</main>
<br><br><br>
<?php include_once(APPPATH.'/views/footer.php'); ?>
</body>
</html>
