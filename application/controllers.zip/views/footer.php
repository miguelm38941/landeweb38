<footer style="">
<?php if($this->ion_auth->in_group(array('agent'))
            || $this->ion_auth->in_group(array('pharmacie'))
            || $this->ion_auth->in_group(array('pnls'))
            || $this->ion_auth->in_group(array('lmsc'))){ ?>
<div style="text-align:center;padding-right:10px;font-size:14px;">
    <a style="color:#000;" title="Cliquer pour t&eacute;l&eacute;charger" href="<?php echo base_url() ?>backend/telecharger/landela_app.apk" class="center-align">T&eacute;l&eacute;charger Landela app</a>
</div>
<?php } ?>
<div style="text-align:right; font-size:11px;color:rgb(185,36,54);margin-top:5px;border-top:1px #ddd solid;padding-right:10px;">&copy; 2018 - Landela | La main sur le coeur - RDC</div>
</footer>
