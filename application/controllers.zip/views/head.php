<!--
<link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.5/css/materialize.min.css">
<script type="text/javascript" src="https://code.jquery.com/jquery-2.1.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.5/js/materialize.min.js"></script>
-->
<link href="<?= base_url('fonts/fonts.css') ?>" rel="stylesheet">
<link rel="stylesheet" href="<?= base_url('css/materialize.min.css'); ?>">
<script type="text/javascript" src="<?= base_url('js/jquery-2.1.1.min.js'); ?>"></script>
<script type="text/javascript" src="<?= base_url('js/materialize.min.js') ?>"></script>
<script type="text/javascript" src="<?= base_url('js/chart.min.js') ?>"></script>
<meta name="viewport" content="width=device-width, initial-scale=1.0"/>
<script type="text/javascript">
window.base_url='<?= base_url() ?>';

</script>
<link rel="stylesheet" href="<?= base_url('css/styles.css') ?>"/>
<script type="text/javascript" src="<?= base_url('js/common.js') ?>"></script>
<script type="text/javascript" src="<?= base_url('js/lgedit.js') ?>"></script>
<script type="text/javascript" src="<?= base_url('js/pagination.js') ?>"></script>

        
