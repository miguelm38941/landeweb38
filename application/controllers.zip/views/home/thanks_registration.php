<html>
<head>
<?php
	include_once(APPPATH.'/views/head.php');
?>
</head>
<body>
<?php
	include_once('menu.php');
?>
<main>
<div class="container">
<h1 style="width:100%" class="center-align">Merci pour votre inscription</h1>
</div>
</main>
<br><br><br>
<?php include_once(APPPATH.'/views/footer.php'); ?>
</body>
</html>
