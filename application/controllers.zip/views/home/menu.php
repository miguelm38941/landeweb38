<div class="navbar-fixed">
<nav id="menu">
	<a href="#" data-activates="mobile-demo" class="button-collapse"><i class="material-icons">menu</i></a>
	<div class="nav-wrapper">
		<a href="<?= site_url('/welcome/') ?>" class="brand-logo"><img src="<?= base_url('/logo.png') ?>"/></a>
	</div>
</nav>
</div>
