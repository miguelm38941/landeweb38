<html>
<head>
<?php
	include_once(APPPATH.'/views/head.php');
?>
<script type="text/javascript">
$(document).ready(function(){
	$("#societe_pharma").on('change',function(){
		var datas = {
			"id":<?= $commande['id'] ?>,
			"societe_pharma" : $(this).val()
		}
		$.post('<?= site_url('/backend/commandes/add_societe_pharma') ?>',datas,function(){
		});
	});
});
</script>
</head>
<body>
<div class="wrapper">
<?php
	include_once(APPPATH.'/views/menu.php');
?>
<main>
<div class="container">
	<br><br>
<h5>Commande de medicament</h5>

<?php
	$dests = get_all_destinataires_commandes();
	$sc = get_societe_pharma();
	$can_save=false;
?>
<table border="1" style="width:30%">
<tr>
	<td>
		Envoyer &agrave; : 
	</td>
</tr>
<tr>
	<td> 
		<form action="">
			Message <br>
			<textarea style="width:500px;height:150px;" name="message"></textarea>
			<br><br>
			<div>
				<a class="btn" href="<?= site_url('/backend/commandes/record/') ?>">Envoyer</a>
			<?php
				if($can_save){
			?>
			<?php
				}
			?>
			</div>
		</form> 
	</td>
</tr>
</table>

</div>
</main>
</div>
<?php include_once(APPPATH.'/views/footer.php'); ?>
</body>
</html>
